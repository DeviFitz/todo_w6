import 'package:flutter/material.dart';

class SignInAccountPage extends StatelessWidget {
  const SignInAccountPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
